//
//  TaskConstants.h
//  TaskFrameworkLibrary
//
//  Created by MADP on 07/09/16.
//  Copyright © 2016 MADP. All rights reserved.
//

#import <Foundation/Foundation.h>

//TODO: Discuss the error domains and codes...

//Context related
FOUNDATION_EXPORT NSString *const kTaskErrors;
FOUNDATION_EXPORT NSString *const kTaskInputContext;
FOUNDATION_EXPORT NSString *const kTaskOutputContext;
FOUNDATION_EXPORT NSString *const kTaskErrorContext;

//Error Domains
FOUNDATION_EXPORT NSString *const kTaskNestedErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskInvalidInputErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskTaskAlreadyStartedErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskCyclicParentChildErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskCyclicDependencyErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskMultipleParentsErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskInvalidDependencyErrorDomain;
FOUNDATION_EXPORT NSString *const kTaskSubtaskMaxTasksReachedErrorDomain;

//Error Codes
static const NSInteger kTaskInvalidInputErrorCode = 1000;
static const NSInteger kTaskNestedErrorCode = 2000;
static const NSInteger kTaskSubtaskTaskAlreadyStartedErrorCode = 3000;
static const NSInteger kTaskSubtaskMaxTasksReachedErrorCode = 3001;
static const NSInteger kTaskSubtaskCyclicDependencyErrorCode = 3002;
static const NSInteger kTaskSubtaskCyclicParentChildErrorCode = 3003;
static const NSInteger kTaskSubtaskMultipleParentsErrorCode = 3004;
static const NSInteger kTaskSubtaskInvalidDependencyErrorCode = 3005;


@interface TaskConstants : NSObject

@end
