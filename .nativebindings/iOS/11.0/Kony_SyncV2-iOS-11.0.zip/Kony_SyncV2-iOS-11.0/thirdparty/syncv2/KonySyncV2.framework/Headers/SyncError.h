//
//  SyncError.h
//  KonySyncV2
//
//  Created by Sunil Phani Manne on 28/11/16.
//  Copyright © 2016 Kony. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "KSConstants.h"

@interface SyncError : NSError

@property (nonatomic, readonly) SyncSessionPhase currentPhase;
@property (nonatomic, readonly, nullable) NSError *cause;

- (nonnull instancetype)initWithDomain:(nullable NSErrorDomain)domain
                                  code:(NSInteger)code
                              userInfo:(nullable NSDictionary *)dict
                              andPhase:(SyncSessionPhase)phase;

- (nonnull instancetype)initWithDomain:(nullable NSErrorDomain)domain
                                  code:(NSInteger)code
                              userInfo:(nullable NSDictionary *)dict
                                 cause:(nullable NSError *)cause;

- (nonnull instancetype)initWithCause:(nullable NSError *)cause
                             andPhase:(SyncSessionPhase)phase;
@end
